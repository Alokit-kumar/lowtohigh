from . import assistant

__version__ = '2.2.0'
