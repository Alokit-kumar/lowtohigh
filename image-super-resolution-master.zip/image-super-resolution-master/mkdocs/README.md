# Image Super-Resolution Documentation

## Building the documentation
- Install MkDocs: `pip install mkdocs mkdocs-material`
- Serve MkDocs: `mkdocs serve` and then go to `http://127.0.0.1:8000/` to view it
- Run `python autogen.py` to auto-generate the code documentation
- Run `bash run_docs.sh` to build documentation
